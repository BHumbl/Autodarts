const previousState = new Map();
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type !== 'alf-window-fullscreen') return;
  const windowId = sender.tab?.windowId;
  if (!Number.isInteger(windowId)) { sendResponse({ok:false,error:'No sender window ID'}); return; }
  (async () => {
    try {
      const current = await chrome.windows.get(windowId);
      if (message.enabled) {
        if (current.state !== 'fullscreen') {
          previousState.set(windowId, current.state === 'minimized' ? 'normal' : current.state);
          await chrome.windows.update(windowId, { state: 'fullscreen', focused: true });
        }
      } else if (current.state === 'fullscreen') {
        const state = previousState.get(windowId) || 'normal';
        previousState.delete(windowId);
        await chrome.windows.update(windowId, { state, focused: true });
      }
      const verified = await chrome.windows.get(windowId);
      if (message.enabled && verified.state !== 'fullscreen') throw new Error('Browser did not enter fullscreen state');
      sendResponse({ok:true,state:verified.state});
    } catch (error) {
      console.error('Autodarts Extra fullscreen error:', error);
      sendResponse({ok:false,error:String(error?.message||error)});
    }
  })();
  return true;
});
chrome.windows.onRemoved.addListener(windowId => previousState.delete(windowId));
