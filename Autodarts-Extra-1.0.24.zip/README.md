###### Autodarts Extra 1.0.24

Korrektur auf Basis der funktionierenden Version 1.0.23.
- Der funktionierende Vollbildmodus mit 1,5 Sekunden Wartezeit bleibt unverändert.
- Das Autodarts-Extra-Icon wird auf jeder /matches/-Route konsequent entfernt.
- Das gilt für das laufende Spiel, die Spielstatistik und den Dialog zum Verlassen eines Spiels.
- Der regelmäßige Menü-Mount darf das Icon auf Match-Routen nicht erneut einsetzen.
- Beim Öffnen des Verlassen-Dialogs erfolgt zusätzlich eine sofortige Entfernung nach dem Klick.
- Spieler per Enter und Mindestlänge von drei Zeichen bleiben unverändert.
